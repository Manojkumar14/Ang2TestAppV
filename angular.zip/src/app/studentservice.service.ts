import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';  

@Injectable()
export class StudentserviceService {

  constructor(private http: HttpClient) { }
  
  getEmployees() {  
    debugger
    return this.http.get<any>("http://localhost:54875/api/values");  
  }  
}
