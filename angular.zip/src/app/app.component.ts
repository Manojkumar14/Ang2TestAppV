import { Component, TemplateRef  } from '@angular/core';
import { StudentserviceService } from './studentservice.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  modalRef: BsModalRef;
  obj;
  id;
  myForm: FormGroup;
  myForm1: FormGroup;
  constructor(private empService: StudentserviceService, private modalService: BsModalService, private formBuilder: FormBuilder) {
    this.createForm();
   }
  ngOnInit() {  
    this.empService.getEmployees()
      .subscribe((data) => {  
        console.log(data);
        this.obj = data;
      }); 
  }  
  private createForm() {
    this.myForm = this.formBuilder.group({
      ID: '',
      Name: '',
      Email:''
    });
    
  }
  editid(obj){
    this.myForm1 = this.formBuilder.group({
      ID: obj.id,
      Name: obj.Name,
      Email: obj.Email
    });
  }
  deletefunction(id){
   
  }
  addfunction(){
  
    console.log(this.myForm.value);
  }
  // closeModal() {
  //   this.activeModal.close('Modal Closed');
  // }
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }
 
  title = 'app';
}
